#
#
# What are the numeric values of letters?
# The code below loops over each letter in the string and prints
# out the letter and its numerical value
alphabet = 'abcdefghijklmnopqrstuvwxyz'
for letter in alphabet:
    print(letter)